<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>TemplateLoader</name>
    <message>
        <location filename="templateLoader.py" line="74"/>
        <source>Créer une carte</source>
        <translation type="unfinished">Create map</translation>
    </message>
</context>
<context>
    <name>TemplateLoader</name>
    <message utf8="true">
        <location filename="../templateLoader_dialog_base.ui" line="14"/>
        <source>Création carte</source>
        <translation type="unfinished">Create map</translation>
    </message>
    <message>
        <location filename="../templateLoader_dialog_base.ui" line="49"/>
        <source>Titre</source>
        <translation type="unfinished">Title</translation>
    </message>
    <message>
        <location filename="../templateLoader_dialog_base.ui" line="62"/>
        <source>Sous- titre</source>
        <translation type="unfinished">Sub-title</translation>
    </message>
    <message>
        <location filename="../templateLoader_dialog_base.ui" line="75"/>
        <source>Sources</source>
        <translation type="unfinished">Sources</translation>
    </message>
    <message>
        <location filename="../templateLoader_dialog_base.ui" line="101"/>
        <source>Num carte</source>
        <translation type="unfinished">Map num.</translation>
    </message>
    <message utf8="true">
        <location filename="../templateLoader_dialog_base.ui" line="133"/>
        <source>Modèle</source>
        <translation type="unfinished">Template</translation>
    </message>
    <message>
        <location filename="../templateLoader_dialog_base.ui" line="155"/>
        <source>Echelle</source>
        <translation type="unfinished">Scale</translation>
    </message>
    <message>
        <location filename="../templateLoader_dialog_base.ui" line="201"/>
        <source>Copyright</source>
        <translation type="unfinished">Copyright</translation>
    </message>
</context>
</TS>
